jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"customerorders/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"customerorders/test/integration/pages/App",
	"customerorders/test/integration/pages/Browser",
	"customerorders/test/integration/pages/Master",
	"customerorders/test/integration/pages/Detail",
	"customerorders/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "customerorders.view."
	});

	sap.ui.require([
		"customerorders/test/integration/NavigationJourneyPhone",
		"customerorders/test/integration/NotFoundJourneyPhone",
		"customerorders/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});