jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 cust in the list
// * All 3 cust have at least one hisorder

sap.ui.require([
	"sap/ui/test/Opa5",
	"customerorders/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"customerorders/test/integration/pages/App",
	"customerorders/test/integration/pages/Browser",
	"customerorders/test/integration/pages/Master",
	"customerorders/test/integration/pages/Detail",
	"customerorders/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "customerorders.view."
	});

	sap.ui.require([
		"customerorders/test/integration/MasterJourney",
		"customerorders/test/integration/NavigationJourney",
		"customerorders/test/integration/NotFoundJourney",
		"customerorders/test/integration/BusyJourney",
		"customerorders/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});